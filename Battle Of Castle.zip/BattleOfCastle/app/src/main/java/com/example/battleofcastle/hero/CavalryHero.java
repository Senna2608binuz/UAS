package com.example.battleofcastle.hero;

public class CavalryHero extends Hero {
    public CavalryHero(String name, int level) {
        super(name, level);
    }

    @Override
    public void statistics() {
        String format = "%-30s %5s %s\n";
        System.out.format(format, "Type", " :  ", this.getClass().getSimpleName());
        super.statistics();
    }
}
