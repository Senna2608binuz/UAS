package com.example.battleofcastle.army;

public class ArcherArmy extends Army {
    public ArcherArmy(String name, double skill, double attack) {
        super(name, skill, attack);
    }

    @Override
    public void statistics() {
        String format = "%-30s %5s %s\n";
        System.out.format(format, "Type", " :  ", this.getClass().getSimpleName());
        super.statistics();
    }
}
