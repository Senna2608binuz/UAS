package com.example.battleofcastle.castle;

public class HorseCastle extends Castle {
}
