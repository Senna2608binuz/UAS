package com.example.battleofcastle.hero;

public class Hero {
    private String name;
    private int level;

    public Hero(String name, int level) {
        this.name = name;
        this.level = level;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public void statistics() {
        String format = "%-30s %5s %s\n";
        System.out.format(format, "Name", " :  ", this.name);
        System.out.format(format, "Level", " :  ", this.level);
        System.out.println("----------------------------------------------------");
    }
}
