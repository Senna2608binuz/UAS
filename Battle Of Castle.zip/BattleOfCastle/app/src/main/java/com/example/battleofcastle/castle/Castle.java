package com.example.battleofcastle.castle;

public class Castle {
}
