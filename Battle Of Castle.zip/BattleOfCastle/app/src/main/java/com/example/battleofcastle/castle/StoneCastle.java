package com.example.battleofcastle.castle;

public class StoneCastle extends Castle {
}
