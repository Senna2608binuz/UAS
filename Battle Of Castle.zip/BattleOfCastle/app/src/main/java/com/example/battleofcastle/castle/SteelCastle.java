package com.example.battleofcastle.castle;

public class SteelCastle extends Castle {
}
