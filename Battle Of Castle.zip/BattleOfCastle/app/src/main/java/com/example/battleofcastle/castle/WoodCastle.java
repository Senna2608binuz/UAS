package com.example.battleofcastle.castle;

public class WoodCastle extends Castle {
}
