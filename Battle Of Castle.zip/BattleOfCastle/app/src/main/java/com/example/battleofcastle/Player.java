package com.example.battleofcastle;

import com.example.battleofcastle.army.ArcherArmy;
import com.example.battleofcastle.army.Army;
import com.example.battleofcastle.army.CatapultArmy;
import com.example.battleofcastle.army.CavalryArmy;
import com.example.battleofcastle.army.InfantryArmy;
import com.example.battleofcastle.castle.Castle;
import com.example.battleofcastle.castle.HorseCastle;
import com.example.battleofcastle.castle.SteelCastle;
import com.example.battleofcastle.castle.WoodCastle;
import com.example.battleofcastle.hero.ArcherHero;
import com.example.battleofcastle.hero.CatapultHero;
import com.example.battleofcastle.hero.CavalryHero;
import com.example.battleofcastle.hero.Hero;
import com.example.battleofcastle.hero.InfantryHero;

import java.util.ArrayList;

public class Player {
  private String name;
  private Castle castle;
  private ArrayList<Hero> heroes;
  private ArrayList<Army> armies;

  private boolean infantryHeroExist = false;
  private boolean cavalryHeroExist = false;
  private boolean archerHeroExist = false;
  private boolean catapultHeroExist = false;

  private int archerCount = 0;
  private int catapultCount = 0;
  private int cavalryCount = 0;
  private int infantryCount = 0;

  public Player(String name, Castle castle, ArrayList<Hero> heroes, ArrayList<Army> armies) {
    this.name = name;
    this.castle = castle;
    this.heroes = heroes;
    this.armies = armies;

    initTroops();
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Castle getCastle() {
    return castle;
  }

  public void setCastle(Castle castle) {
    this.castle = castle;
    boostSkill();
  }

  public ArrayList<Hero> getHeroes() {
    return heroes;
  }

  public void setHeroes(ArrayList<Hero> heroes) {
    this.heroes = heroes;
    boostAttack();
  }

  public ArrayList<Army> getArmies() {
    return armies;
  }

  public void setArmies(ArrayList<Army> armies) {
    this.armies = armies;
  }

  public boolean isInfantryHeroExist() {
    return infantryHeroExist;
  }

  public void setInfantryHeroExist(boolean infantryHeroExist) {
    this.infantryHeroExist = infantryHeroExist;
  }

  public boolean isCavalryHeroExist() {
    return cavalryHeroExist;
  }

  public void setCavalryHeroExist(boolean cavalryHeroExist) {
    this.cavalryHeroExist = cavalryHeroExist;
  }

  public boolean isArcherHeroExist() {
    return archerHeroExist;
  }

  public void setArcherHeroExist(boolean archerHeroExist) {
    this.archerHeroExist = archerHeroExist;
  }

  public boolean isCatapultHeroExist() {
    return catapultHeroExist;
  }

  public void setCatapultHeroExist(boolean catapultHeroExist) {
    this.catapultHeroExist = catapultHeroExist;
  }


  public void initTroops() {
    double archerBoost = 0;
    double catapultBoost = 0;
    double cavalryBoost = 0;
    double infantryBoost = 0;
    for (Hero hero : this.heroes) {
      if (hero instanceof ArcherHero) archerBoost += 0.4;
      else if (hero instanceof CatapultHero) catapultBoost += 0.4;
      else if (hero instanceof CavalryHero) cavalryBoost += 0.4;
      else if (hero instanceof InfantryHero) infantryBoost += 0.4;
    }

    for (Army army : this.armies) {
      if (army instanceof ArcherArmy) archerCount++;
      else if (army instanceof CatapultArmy) catapultCount++;
      else if (army instanceof CavalryArmy) cavalryCount++;
      else if (army instanceof InfantryArmy) infantryCount++;
    }

    this.archerCount += (int) (archerBoost * archerCount);
    this.catapultCount += (int) (catapultBoost * catapultCount);
    this.cavalryCount += (int) (cavalryBoost * cavalryCount);
    this.infantryCount += (int) (infantryBoost * infantryCount);
  }

  public int getArcherCount() {
    return archerCount;
  }

  public int getCatapultCount() {
    return catapultCount;
  }

  public int getCavalryCount() {
    return cavalryCount;
  }

  public int getInfantryCount() {
    return infantryCount;
  }

  private void boostSkill() {
    if (this.castle instanceof HorseCastle) {
      for (Army army : armies) {
        if (army instanceof CavalryArmy) {
          army.boostSkill();
        }
      }
    } else if (this.castle instanceof WoodCastle) {
      for (Army army : armies) {
        if (army instanceof ArcherArmy) {
          army.boostSkill();
        }
      }
    } else if (this.castle instanceof SteelCastle) {
      for (Army army : armies) {
        if (army instanceof InfantryArmy) {
          army.boostSkill();
        }
      }
    } else {
      for (Army army : armies) {
        if (army instanceof CatapultArmy) {
          army.boostSkill();
        }
      }
    }
  }

  private void boostAttack() {
    for (Hero hero : heroes) {
      if (hero instanceof InfantryHero) {
        this.infantryHeroExist = true;
        for (Army army : armies) {
          if (army instanceof InfantryArmy) {
            army.boostAttack();
          }
        }
      } else if (hero instanceof CavalryHero) {
        this.cavalryHeroExist = true;
        for (Army army : armies) {
          if (army instanceof CavalryArmy) {
            army.boostAttack();
          }
        }
      } else if (hero instanceof ArcherHero) {
        this.archerHeroExist = true;
        for (Army army : armies) {
          if (army instanceof ArcherArmy) {
            army.boostAttack();
          }
        }
      } else if (hero instanceof CatapultHero) {
        this.catapultHeroExist = true;
        for (Army army : armies) {
          if (army instanceof CatapultArmy) {
            army.boostAttack();
          }
        }
      }
    }
  }

  public void statistics() {
    String format = "%-30s %5s %s\n";
    System.out.println("====================================================");
    System.out.format(format, "Name", " :  ", this.name);
    System.out.format(format, "Castle Skin", " :  ", this.castle.getClass().getSimpleName());
    System.out.format(format, "Number of Heroes", " :  ", this.heroes.size());
    System.out.println("Hero List: ");
    System.out.println("----------------------------------------------------");
    for (Hero hero : this.heroes) {
      hero.statistics();
    }
    System.out.format(format, "Number of Armies", " :  ", this.armies.size());
    System.out.println("Army List: ");
    System.out.println("----------------------------------------------------");
    for (Army army : this.armies) {
      army.statistics();
    }
    System.out.println("====================================================");
  }
}
