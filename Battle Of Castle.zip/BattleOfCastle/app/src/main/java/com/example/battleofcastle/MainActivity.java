package com.example.battleofcastle;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.battleofcastle.army.ArcherArmy;
import com.example.battleofcastle.army.Army;
import com.example.battleofcastle.army.CavalryArmy;
import com.example.battleofcastle.army.InfantryArmy;
import com.example.battleofcastle.castle.Castle;
import com.example.battleofcastle.castle.HorseCastle;
import com.example.battleofcastle.castle.SteelCastle;
import com.example.battleofcastle.castle.StoneCastle;
import com.example.battleofcastle.castle.WoodCastle;
import com.example.battleofcastle.hero.ArcherHero;
import com.example.battleofcastle.hero.CatapultHero;
import com.example.battleofcastle.hero.CavalryHero;
import com.example.battleofcastle.hero.Hero;
import com.example.battleofcastle.hero.InfantryHero;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
  private ImageView imgPlayerA, imgPlayerB, imgWinA, imgWinB;
  private TextView txtWarTitle;
  private Button btnFight;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    imgPlayerA = findViewById(R.id.imagePlayerA);
    imgPlayerB = findViewById(R.id.imagePlayerB);
    imgWinA = findViewById(R.id.imageWinPlayerA);
    imgWinB = findViewById(R.id.imageWinPlayerB);
    txtWarTitle = findViewById(R.id.textWarTitle);
    btnFight = findViewById(R.id.buttonFight);

    initiateFirstFight();
  }

  private void initiateFirstFight() {
    txtWarTitle.setText("Cavalry vs Archer");
    Castle castleA = new HorseCastle();
    ArrayList<Hero> heroesA = new ArrayList<>();
    ArrayList<Army> armiesA = new ArrayList<>();

    for (int i = 0; i < 5; i++) {
      heroesA.add(new CavalryHero("Cavalry Hero " + (i + 1), 100));
    }

    for (int i = 0; i < 100000; i++) {
      armiesA.add(new CavalryArmy("Cavalry Army " + (i + 1), 100, 100));
    }

    Castle castleB = new WoodCastle();
    ArrayList<Hero> heroesB = new ArrayList<>();
    ArrayList<Army> armiesB = new ArrayList<>();

    for (int i = 0; i < 5; i++) {
      heroesB.add(new ArcherHero("Archer Hero " + (i + 1), 100));
    }

    for (int i = 0; i < 100000; i++) {
      armiesB.add(new ArcherArmy("Archer Army " + (i + 1), 100, 100));
    }

    Player playerA = new Player("Player A", castleA, heroesA, armiesA);
    Player playerB = new Player("Player B", castleB, heroesB, armiesB);

    loadImage(heroesA.get(0), imgPlayerA);
    loadImage(heroesB.get(0), imgPlayerB);

    btnFight.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        startFirstFight(playerA, playerB);
      }
    });
  }

  private void startFirstFight(Player playerA, Player playerB) {
    int playerATroops = playerA.getCavalryCount();
    int playerBTroops = playerB.getArcherCount();

    playerATroops -= 0.4 * playerB.getArcherCount();
    playerBTroops -= 0.1 * playerA.getCavalryCount();

    setWinner(playerATroops, playerBTroops);

    btnFight.setText("Next Battle");
    btnFight.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        initiateSecondFight();
      }
    });
  }

  private void initiateSecondFight() {
    resetBattleField();
    txtWarTitle.setText("Mix Armies vs Infantry");
    Castle castleA = new StoneCastle();
    ArrayList<Hero> heroesA = new ArrayList<>();
    ArrayList<Army> armiesA = new ArrayList<>();

    for (int i = 0; i < 3; i++) {
      heroesA.add(new ArcherHero("Archer Hero " + (i + 1), 100));
    }

    for (int i = 0; i < 60000; i++) {
      armiesA.add(new ArcherArmy("Archer Army " + (i + 1), 100, 100));
    }

    for (int i = 0; i < 2; i++) {
      heroesA.add(new CavalryHero("Cavalry Hero " + (i + 1), 100));
    }

    for (int i = 0; i < 40000; i++) {
      armiesA.add(new CavalryArmy("Cavalry Army " + (i + 1), 100, 100));
    }

    Castle castleB = new SteelCastle();
    ArrayList<Hero> heroesB = new ArrayList<>();
    ArrayList<Army> armiesB = new ArrayList<>();

    for (int i = 0; i < 5; i++) {
      heroesB.add(new InfantryHero("Infantry Hero " + (i + 1), 100));
    }

    for (int i = 0; i < 100000; i++) {
      armiesB.add(new InfantryArmy("Infantry Army " + (i + 1), 100, 100));
    }

    Player playerA = new Player("Player A", castleA, heroesA, armiesA);
    Player playerB = new Player("Player B", castleB, heroesB, armiesB);

    loadImage(heroesA.get(0), imgPlayerA);
    loadImage(heroesB.get(0), imgPlayerB);

    btnFight.setText("FIGHT");
    btnFight.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        startSecondFight(playerA, playerB);
      }
    });
  }

  private void startSecondFight(Player playerA, Player playerB) {
    int playerATroopsArcher = playerA.getArcherCount();
    int playerATroopsCavalry = playerA.getCavalryCount();

    int playerBTroops = playerB.getInfantryCount();

    playerATroopsArcher -= 0.4 * playerB.getInfantryCount();
    playerATroopsCavalry -= 0.1 * playerB.getInfantryCount();

    playerBTroops -= 0.1 * playerA.getArcherCount();
    playerBTroops -= 0.4 * playerA.getCavalryCount();

    setWinner(playerATroopsArcher + playerATroopsCavalry, playerBTroops);

    btnFight.setText("Exit");
    btnFight.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        finish();
      }
    });
  }

  private void loadImage(Hero hero, ImageView imageView) {
    if (hero instanceof ArcherHero) {
      imageView.setImageResource(R.drawable.ic_archer);
    } else if (hero instanceof CatapultHero) {
      imageView.setImageResource(R.drawable.ic_catapult);
    } else if (hero instanceof CavalryHero) {
      imageView.setImageResource(R.drawable.ic_cavalry);
    } else if (hero instanceof InfantryHero) {
      imageView.setImageResource(R.drawable.ic_infantry);
    }
  }

  private void setWinner(int a, int b) {
    if (a > b) {
      imgWinA.setVisibility(View.VISIBLE);
    } else if (a < b) {
      imgWinB.setVisibility(View.VISIBLE);
    }
  }

  private void resetBattleField() {
    txtWarTitle.setText("");
    imgWinA.setVisibility(View.INVISIBLE);
    imgWinB.setVisibility(View.INVISIBLE);
  }
}